# block-world-cn-pack

**Mineclonia 中文整合包「方块生存离线版」的自制部分开源仓库** —— 基于 Luanti 5.17.0 引擎 + Mineclonia 0.123.1（我的世界中文生存版）的本地化增强与工具集。

> 本仓库只包含**自制内容**（中文指南 mod、作弊指令 mod、优化配置、自动化测试、翻译资产）。
> Luanti 引擎与 Mineclonia 游戏本体属于上游项目，未打包在内，按下方「依赖」说明获取。

## 依赖

| 组件 | 版本 | 来源 |
|---|---|---|
| Luanti（引擎） | 5.17.0 | https://github.com/luanti-org/luanti（Windows 便携版解压即用） |
| Mineclonia（游戏） | 0.123.1 | https://content.luanti.org/packages/Wuzzy/mineclonia/ 或 git clone https://github.com/mcl-mods/mineclonia |

组装方式：把 Mineclonia 放到 `engine/luanti-5.17.0-win64/games/mineclonia`，启动 `启动游戏.bat`。

## 自制内容清单

### 1. 中文生存指南 mod（mcl_zh_guide）
- 新玩家首次进入世界自动弹出，之后 `/guide` 命令随时打开；共 3 页（生存入门 / 键位速查 / 进阶提示）
- 位置：`mods/MISC/mcl_zh_guide/`（拷入 Mineclonia 的 `mods/MISC/` 即可，MISC 子目录由 modpack.conf 自动加载）

### 2. 作弊指令 mod（mcl_zh_cheats）
- `/cheats on|off|status` —— 作弊模式开关（世界级持久保存）
- `/gamemode creative|survival` —— 切换模式（需先开作弊，包装 Mineclonia 原生命令）
- `/gamerule keepInventory true|false` —— 死亡不掉落；`/gamerule doDaylightCycle true|false` —— 昼夜循环
- 单机玩家自动授予管理员权限，全部中文反馈
- 位置：`mods/MISC/mcl_zh_cheats/`

### 3. 优化配置（config/minetest.conf）
- 视距 72 / 阴影 1024 / 中文语言 `language = zh_CN` / 关闭配方书渐进模式（全配方可见）/ 树叶恢复原版调色板

### 4. 中文翻译资产（sources/zh_pack/）
- Mineclonia 官方已带 139 个 mod 的 `zh_CN.po` 翻译（含全部物品名），配置 `language = zh_CN` 即生效
- 另备自制 `.tr` 翻译管线（46 mod / 1279 条全译词典 + 生成脚本 + 离线校验器），某 mod 官方翻译缺失时可用——详见 `sources/zh_pack/README.txt`

### 5. 工具脚本
- `启动游戏.bat` —— 一键启动（自动定位引擎与游戏）
- `备份存档.bat` —— worlds 目录滚动备份（保留最近 3 份）

### 6. 自动化测试（test/）
- `zh-cheats-test/worldmods/test_cheats` —— 作弊指令 server 侧集成测试（9/9 全绿，零 ERROR）
- `zh-cheats-test/worldmods/test_trans` —— 翻译管线冒烟测试
- 测试结果与冒烟日志随仓库提供，可复跑

## 快速开始

1. 按「依赖」获取 Luanti 5.17.0 + Mineclonia 0.123.1 并组装目录
2. 拷贝本仓库文件：
   ```
   mods/MISC/mcl_zh_guide, mcl_zh_cheats  → games/mineclonia/mods/MISC/
   config/minetest.conf                    → 整合包 config/
   启动游戏.bat, 备份存档.bat                → 整合包根目录
   ```
3. 双击「启动游戏.bat」

## 实测记录（screenshots/）

- 暂停菜单、物品栏「制作」标签、悬浮提示均为中文（官方 zh_CN.po + language=zh_CN 生效）
- 作弊指令 9/9 集成测试通过（`test/zh-cheats-test/cheats-test-results.txt`）

## 许可

- 自制 Lua 代码（mods/）：MIT License，见 [LICENSE](./LICENSE)
- 自制文档（README、使用说明等）：CC BY-SA 4.0
- 上游组件：Luanti 为 LGPL-2.1-or-later；Mineclonia 为 CC-BY-SA-SA 系列许可，归各自上游所有
- 本仓库不含任何上游二进制或资源文件
