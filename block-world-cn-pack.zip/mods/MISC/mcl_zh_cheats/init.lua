-- mcl_zh_cheats — 作弊指令（方块生存离线版定制）
-- Minecraft 风格指令层：
--   /cheats on|off|status            开关作弊模式（世界级，随存档保存）
--   /gamemode creative|survival      切换游戏模式（包装 Mineclonia 原生命令，加作弊门控）
--   /gamerule keepInventory true     死亡保留物品栏（桥接 Mineclonia 的 mcl_keepInventory 设置）
--   /gamerule doDaylightCycle true   昼夜循环开关
-- 需先 /cheats on 开启作弊；单机玩家默认拥有管理员权限，多人服需管理员 /grant 玩家 server。
-- 纯 Lua 包装与 mod storage，不改 Mineclonia 底座文件，升级底座重拷本目录即可。

core.log("action", "[mcl_zh_cheats] 作弊指令已加载（/cheats /gamemode /gamerule）")

local storage = core.get_mod_storage()

local function load_flag(key)
	return storage:get_string(key) == "true"
end

local function save_flag(key, v)
	storage:set_string(key, v and "true" or "false")
end

local cheats_enabled = load_flag("cheats_enabled")

-- ---------------- /gamerule ----------------

local GAMERULES = {
	keepInventory = {
		desc = "死亡后是否保留物品栏",
		get = function()
			return core.settings:get_bool("mcl_keepInventory", false)
		end,
		set = function(v)
			core.settings:set_bool("mcl_keepInventory", v)
			save_flag("gamerule_keepInventory", v)
		end,
	},
	doDaylightCycle = {
		desc = "是否进行昼夜循环",
		get = function()
			local speed = tonumber(core.settings:get("time_speed")) or 72
			return speed > 0
		end,
		set = function(v)
			core.settings:set_int("time_speed", v and 72 or 0)
			save_flag("gamerule_doDaylightCycle", v)
		end,
	},
}

local function gamerule_list()
	local list = {}
	for k, v in pairs(GAMERULES) do
		list[#list + 1] = k .. "（" .. v.desc .. "）"
	end
	table.sort(list)
	return table.concat(list, "、")
end

core.register_chatcommand("gamerule", {
	params = "<规则名> [true|false]",
	description = "查看或设置游戏规则；需先 /cheats on 开启作弊模式",
	func = function(name, param)
		if not cheats_enabled then
			return false, "需要先开启作弊模式：输入 /cheats on（单机玩家可直接使用）"
		end
		local args = param:split(" ")
		local rule = GAMERULES[args[1]]
		if not rule then
			return false, "未知规则。可用规则：" .. gamerule_list()
		end
		if not args[2] or args[2] == "" then
			return true, "游戏规则 " .. args[1] .. " = " .. tostring(rule.get()) .. "（" .. rule.desc .. "）"
		end
		local v = args[2]:lower()
		if v ~= "true" and v ~= "false" then
			return false, "取值必须为 true 或 false，例如：/gamerule " .. args[1] .. " true"
		end
		rule.set(v == "true")
		return true, "已设置游戏规则 " .. args[1] .. " = " .. v
	end,
})

-- 世界加载后把存档里的规则恢复到运行时设置（保证重启后仍生效）
core.after(0, function()
	for k, rule in pairs(GAMERULES) do
		local saved = storage:get_string("gamerule_" .. k)
		if saved ~= "" then
			rule.set(saved == "true")
		end
	end
end)

-- ---------------- /cheats ----------------

core.register_chatcommand("cheats", {
	params = "on|off|status",
	description = "开关作弊模式（世界级）；开启后可用 /gamemode、/gamerule",
	func = function(name, param)
		local arg = param:trim():lower()
		if arg == "on" or arg == "开" then
			cheats_enabled = true
			save_flag("cheats_enabled", true)
			return true, "作弊模式已开启：现在可以使用 /gamemode、/gamerule 等作弊指令。"
		elseif arg == "off" or arg == "关" then
			cheats_enabled = false
			save_flag("cheats_enabled", false)
			return true, "作弊模式已关闭：/gamemode、/gamerule 已禁用。"
		elseif arg == "" or arg == "status" then
			return true, "作弊模式当前：" .. (cheats_enabled and "开启" or "关闭")
				.. "。开启方法：/cheats on"
		end
		return false, "用法：/cheats on|off|status"
	end,
})

-- ---------------- 单机自动授权 ----------------
-- Luanti 5.17 单机玩家默认只有 interact/shout,没有 server 权限,
-- 会被引擎权限层拦住(/gamemode /cheats 均要求 server),报英文
-- "You don't have permission"。单机玩家=本机主人,进世界时自动补齐。
core.register_on_joinplayer(function(player)
	if not core.is_singleplayer() then return end
	local name = player:get_player_name()
	local privs = core.get_player_privs(name)
	if not privs.server then
		privs.server = true
		core.set_player_privs(name, privs)
		core.log("action", "[mcl_zh_cheats] 单机模式:已自动授予玩家 " .. name .. " 管理员权限")
	end
end)

-- ---------------- 包装原生 /gamemode 加作弊门控 ----------------
-- after(0) 延迟到全部 mod 加载完成后执行；保留原函数，仅在校验通过后放行。
core.after(0, function()
	local gamemode_cmd = core.registered_chatcommands["gamemode"]
	if not gamemode_cmd then
		core.log("warning", "[mcl_zh_cheats] 未找到原生 /gamemode 命令，跳过包装")
		return
	end
	local orig_func = gamemode_cmd.func
	gamemode_cmd.func = function(name, param)
		if not cheats_enabled then
			return false, "需要先开启作弊模式：输入 /cheats on，然后 /gamemode creative 或 /gamemode survival"
		end
		return orig_func(name, param)
	end
	gamemode_cmd.description = "切换游戏模式（survival/creative/0/1/s/c）；需先 /cheats on 开启作弊"
end)
