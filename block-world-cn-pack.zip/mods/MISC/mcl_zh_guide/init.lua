-- mcl_zh_guide — 中文生存指南（方块生存离线版定制）
-- 移植自自研「方块世界」的游玩指南：新玩家首次进入自动弹出，/guide 随时打开。
-- 纯引擎 API，不依赖任何 Mineclonia mod，升级底座时重拷本目录即可。

core.log("action", "[mcl_zh_guide] 中文生存指南已加载（/guide 命令可用）")

local FORMNAME = "mcl_zh_guide:guide"

local PAGES = {
	{
		title = "生存入门（第一个昼夜）",
		body = [[
1. 撸树：对准树干按住左键，拾取掉落的原木。
2. 合成：按 I 打开背包，把原木放进合成格得到木板；
   4 块木板合成工作台，放置后右键打开 3×3 合成。
3. 配方指南：合成界面内自带全部配方列表，点开即看做法。
4. 工具：木板 + 木棍做木镐；挖到石头后升级石质工具。
5. 熔炉：8 个圆石合成；右键放入矿石与燃料（煤 / 木板）冶炼。
6. 食物：猎杀动物得生肉，熔炉烤熟更管饱；
   锄头耕地播种小麦，成熟后收割做成面包。
7. 床：3 羊毛 + 3 木板合成；天黑右键睡觉可跳过夜晚。
8. 夜晚危险：僵尸会主动攻击；苦力怕靠近后会嘶嘶作响并爆炸，
   炸毁地形——保持距离用剑解决它。]],
	},
	{
		title = "键位速查",
		body = [[
W / A / S / D    移动              空格        跳跃
Ctrl 或双击 W    疾跑              Shift       潜行（防坠落）
鼠标左键         采集 / 攻击
鼠标右键         放置 / 使用 / 打开箱子熔炉
I 或 E           背包与合成        Q           丢弃手中物品
1~9 / 滚轮       切换快捷栏
F5               切换视角（第一 / 第三人称）
F12              游戏截图（PNG）
T                聊天 / 命令       Esc         暂停菜单
输入 /guide      随时打开本指南

常用指令（T 打开聊天输入）：
/cheats on       开启作弊模式（世界级）
/cheats off      关闭作弊模式
/gamemode creative  切换创造模式（需先开作弊）
/gamemode survival  切换生存模式
/gamerule keepInventory true  死亡保留物品
/gamerule doDaylightCycle false  暂停昼夜

小技巧：聊天框或其他界面卡住时，先按 Shift 关闭它，再按 T 就能正常输入。
配方书搜索要用英文（物品暂无中文翻译，对照表见第 3 页）。

按键可在 Esc → 选项 → 按键设置 中修改。]],
	},
	{
		title = "进阶提示",
		body = [[
· 配方书搜索小词典（用英文搜，输入中文会显示无物品）：
  钻石 diamond   铁 iron     金 gold      煤 coal
  木头 wood      石头 stone   圆石 cobblestone
  镐 pickaxe     剑 sword    斧 axe       锹 shovel
  头盔 helmet    胸甲 chestplate  护腿 leggings  靴子 boots
  面包 bread     生肉 porkchop/beef   熔炉 furnace
  火把 torch     箱子 chest   床 bed       玻璃 glass
  例：搜 diamond 出全部钻石装备与工具配方。
· 箱子：8 块木板合成，27 格存储，右键打开；物品随存档保存。
· 农业扩展：胡萝卜、土豆、甜菜也可种植；种子可吸引繁殖动物。
· 村民：可交易；村庄在世界中自然生成。
· 下界：黑曜石搭 4×5 门框、用打火石点燃（危险，备好装备再去）。
· 盔甲与附魔：铁砧 + 附魔台提升装备（中后期内容）。
· 存档位置：engine\luanti-5.17.0-win64\worlds；
  双击「备份存档.bat」滚动备份最近 3 份。
· 卡顿：Esc → 选项 → 图像，调低视距 / 关闭阴影。]],
	},
}

local function show_guide(player, page)
	if not player then return end
	page = math.floor(tonumber(page) or 1)
	page = math.max(1, math.min(#PAGES, page))
	player:get_meta():set_int("zh_guide_page", page)
	local p = PAGES[page]
	local fs = "formspec_version[5]size[15,10]bgcolor[#00000099;false]"
		.. "label[0.7,0.85;" .. core.formspec_escape("方块世界生存指南 — " .. p.title) .. "]"
		.. "textarea[0.7,1.5;13.6,7.0;;;" .. core.formspec_escape(p.body) .. "]"
		.. "label[0.7,9.35;" .. core.formspec_escape("第 " .. page .. " / " .. #PAGES .. " 页") .. "]"
	if page > 1 then
		fs = fs .. "button[10.0,9.0;1.6,0.75;prev;上一页]"
	end
	if page < #PAGES then
		fs = fs .. "button[11.8,9.0;1.6,0.75;next;下一页]"
	end
	fs = fs .. "button_exit[13.6,9.0;0.9,0.75;quit;关]"
	core.show_formspec(player:get_player_name(), FORMNAME, fs)
end

core.register_on_player_receive_fields(function(player, formname, fields)
	if formname ~= FORMNAME then return end
	local page = player:get_meta():get_int("zh_guide_page")
	if fields.next then
		show_guide(player, page + 1)
	elseif fields.prev then
		show_guide(player, page - 1)
	end
end)

-- 新玩家：首次进入 1.5 秒后自动弹出（等 HUD 就绪）
core.register_on_newplayer(function(player)
	player:get_meta():set_int("zh_guide_page", 1)
	local name = player:get_player_name()
	core.after(1.5, function()
		show_guide(core.get_player_by_name(name), 1)
	end)
end)

-- 老玩家：meta 里没记过页码的视为没看过指南，也弹一次
core.register_on_joinplayer(function(player)
	local meta = player:get_meta()
	if meta:get("zh_guide_page") == nil then
		meta:set_int("zh_guide_page", 1)
		local name = player:get_player_name()
		core.after(2.0, function()
			show_guide(core.get_player_by_name(name), 1)
		end)
	end
end)

core.register_chatcommand("guide", {
	description = "打开中文生存指南",
	func = function(name)
		show_guide(core.get_player_by_name(name), 1)
		return true
	end,
})
