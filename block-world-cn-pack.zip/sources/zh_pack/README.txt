Mineclonia 中文翻译资料 (zh_pack)
=================================
日期: 2026-10-07

★ 重要结论（先读这个）
----------------------
Mineclonia 0.123.1 官方自带 139 个 mod 的简中翻译（locale/*.zh_CN.po，gettext 格式，
Luanti 5.4+ 原生支持），且 config/minetest.conf 与引擎默认配置均已有 language = zh_CN。
物品名显示中文 + 配方书中文搜索本就应当可用；此前用户看到全英文，
判断为语言设置未生效/未重启游戏所致（时序无法精确考证）。

因此本次自制的 44 个 mod 的 zh_CN.tr 已全部回滚删除，避免与官方 .po 同 textdomain
并存产生未文档化的优先级冲突。词典与脚本保留在此目录作为备用资产：
若未来某个 mod 的 zh_CN.po 缺失或质量太差，可用本目录资料为其生成 .tr 补齐。

文件说明
--------
- batch1_strings.json: 46 个 mod 提取的原文（mod -> 字符串数组，按索引）
- dict_part1-6.py + dict_extra.py: 中文翻译词典（与 JSON 索引逐条对齐，1279 条全译）
- gen_tr.py: 生成脚本（写 mods/<mod>/locale/zh_CN.tr）
- verify_tr.py: 离线校验（模拟 Luanti 解析器，验证 key 与运行时 S() 字符串一一对应）

本批实测记录（.tr 路线，已回滚但脚本可用）
------------------------------------------
- 生成: 44 文件 1279 条全部写入成功
- server 冒烟: 日志 0 ERROR；get_translator 10/10 mod 可用；占位符 @1/@2 参数
  替换证据确凿（server 侧 get_translator 走 \x1b(T@<mod>) escape 转发，译文由
  客户端引擎渲染——server 侧查词永远返回 escape 串，这是 5.x 正常机制）
- 离线校验: 1279/1279 key 与运行时字符串一一对应，0 格式异常
- 踩坑: ①原文含 = （如 "(X=0, Z=0)"、"Y=16"）必须写成 \=，行首 # 写 \#；
  ②译文真实换行写入 .tr 会断行，必须转成字面 \n；③core.translate 对含
  @1..@9 的字符串要求按序传参，缺参会 ServerError 崩溃
- 重灌: 先重跑提取生成新 batch1_strings.json（底座升级后索引会变，词典需人工核对），
  再 python gen_tr.py，最后 python verify_tr.py

若需补 .po 路线（未来）：gettext 格式，msgstr 直接填中文，语法比 .tr 宽松，
推荐 poedit 或直接文本编辑；.po 的 \n 是真实多行消息（msgid 跨行用连续字符串）。
