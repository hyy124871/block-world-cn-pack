# -*- coding: utf-8 -*-
"""生成 Mineclonia 各 mod 的 locale/zh_CN.tr 文件。
用法: python gen_tr.py
数据: batch1_strings.json (原文, 按索引) + dict_part1-6.py (译文, 按索引对齐)
"""
import json, os, sys, re, importlib.util

BASE = r"C:\Users\黄奕阳\Desktop\方块生存离线版"
MODS_DIR = os.path.join(BASE, "engine", "luanti-5.17.0-win64", "games", "mineclonia", "mods")
ARCHIVE_DIR = os.path.join(BASE, "sources", "zh_pack")
HERE = os.path.dirname(os.path.abspath(__file__))

def load_json(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)

def load_dict_part(name):
    spec = importlib.util.spec_from_file_location(name, os.path.join(HERE, name + ".py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m.DATA

def escape_key(s):
    """key 转义: 保留已有的字面 \\n; 其余反斜杠翻倍; = 转成 \\=; 行首 # 转成 \\#"""
    s = s.replace("\\n", "\x00")      # 保护提取自 Lua 源码的字面 \n
    s = s.replace("\\", "\\\\")
    s = s.replace("=", "\\=")          # Luanti parser 按第一个 = 分割
    s = s.replace("\x00", "\\n")
    if s.startswith("#"):
        s = "\\#" + s[1:]
    return s

def escape_value(s):
    """value 转义: 真实换行 -> 字面 \\n; 反斜杠翻倍"""
    s = s.replace("\\", "\\\\")
    s = s.replace("\n", "\\n")
    return s

def main():
    strings = load_json(os.path.join(HERE, "batch1_strings.json"))

    TR = {}
    for i in range(1, 7):
        TR.update(load_dict_part("dict_part%d" % i))
    TR.update(load_dict_part("dict_extra"))
    # dict_part1 的 DATA 是 {"mcl_core": [...]} 结构；part2-6 同构
    total_trans, total_missing, total_skip = 0, 0, 0
    report = []
    esc_report = set()

    # 建立 mod 名 -> 目录路径 映射（扫描 mods 下所有 mod.conf）
    mod_paths = {}
    for root, dirs, files in os.walk(MODS_DIR):
        if "mod.conf" in files:
            with open(os.path.join(root, "mod.conf"), encoding="utf-8") as f:
                for line in f:
                    m = re.match(r"\s*name\s*=\s*(\S+)", line)
                    if m:
                        mod_paths[m.group(1)] = root
                        break

    for mod, arr in sorted(strings.items()):
        if not arr:
            report.append("%s: 0 条, 跳过" % mod)
            total_skip += 0
            continue
        trans = TR.get(mod)
        if trans is None:
            report.append("%s: !! 词典缺失, %d 条未翻译" % (mod, len(arr)))
            total_missing += len(arr)
            continue
        if len(trans) != len(arr):
            report.append("%s: !! 长度不匹配 词典=%d 原文=%d, 跳过" % (mod, len(trans), len(arr)))
            total_missing += len(arr)
            continue
        # 扫描原文中的反斜杠转义
        for s in arr:
            for m in re.finditer(r"\\.", s):
                if m.group(0) != "\\n":
                    esc_report.add(mod + ": " + repr(m.group(0)) + " in " + s[:40])
        lines = ["# textdomain: " + mod]
        n = 0
        for orig, zh in zip(arr, trans):
            if zh is None:
                continue
            lines.append(escape_key(orig) + "=" + escape_value(zh))
            n += 1
        mp = mod_paths.get(mod)
        if mp is None:
            report.append("%s: !! 找不到 mod 目录, %d 条未写入" % (mod, n))
            total_missing += n
            continue
        loc = os.path.join(mp, "locale")
        os.makedirs(loc, exist_ok=True)
        out = os.path.join(loc, "zh_CN.tr")
        with open(out, "w", encoding="utf-8", newline="\n") as f:
            f.write("\n".join(lines) + "\n")
        total_trans += n
        report.append("%s: %d/%d 条 -> %s" % (mod, n, len(arr), os.path.relpath(out, BASE)))

    print("\n".join(report))
    print("-" * 60)
    print("已翻译: %d, 未翻译/跳过: %d" % (total_trans, total_missing))
    if esc_report:
        print("!! 原文含非常规转义序列 (需人工核对):")
        for e in sorted(esc_report):
            print("  " + e)

    # 归档
    os.makedirs(ARCHIVE_DIR, exist_ok=True)
    import shutil
    for name in ["batch1_strings.json", "dict_extra.py"] + ["dict_part%d.py" % i for i in range(1, 7)]:
        shutil.copy2(os.path.join(HERE, name), os.path.join(ARCHIVE_DIR, name))
    with open(os.path.join(ARCHIVE_DIR, "README.txt"), "w", encoding="utf-8") as f:
        f.write("""Mineclonia 中文翻译包 (zh_CN) 生成资料
=====================================
生成时间: 2026-10-07
覆盖: 第一批 46 个 mod 的 1279 条 S() 字符串 (物品/方块名为主)

文件说明:
- batch1_strings.json: 从 Mineclonia 0.123.1 提取的原文 (mod -> 字符串数组, 按索引)
- dict_part1-6.py: 中文翻译词典 (与 JSON 索引逐条对齐, None = 未翻译)
- gen_tr.py: 生成脚本

重灌方法 (底座升级后):
1. 重新运行提取脚本生成新的 batch1_strings.json (索引可能与旧版不同, 需核对词典)
2. python gen_tr.py
3. 词典按当时提取顺序索引, 底座升级后必须人工抽查若干条确认对齐
""")

if __name__ == "__main__":
    main()
