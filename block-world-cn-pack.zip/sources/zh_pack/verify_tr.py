# -*- coding: utf-8 -*-
"""离线校验 zh_CN.tr：
1. 模拟 Luanti builtin/game/translations.lua 解析逻辑（首行 textdomain、# 注释、key=value、\\n 转义）
2. key 集合必须与 batch1_strings.json 原文 unescape 后完全一致（保证运行时 S() 查找命中）
"""
import json, os, re, sys

BASE = r"C:\Users\黄奕阳\Desktop\方块生存离线版"
MODS_DIR = os.path.join(BASE, "engine", "luanti-5.17.0-win64", "games", "mineclonia", "mods")
HERE = os.path.dirname(os.path.abspath(__file__))

def unescape_translate(s):
    """模拟 Luanti unescape_translate"""
    out, esc = [], False
    for ch in s:
        if esc:
            m = {"n": "\n", "s": " ", "=": "=", "#": "#", "\\": "\\"}
            out.append(m.get(ch, "\\" + ch))
            esc = False
        elif ch == "\\":
            esc = True
        else:
            out.append(ch)
    if esc:
        out.append("\\")
    return "".join(out)

def split_key_value(line):
    """按第一个未转义的 = 分割（\\= 是字面等号）"""
    i = 0
    n = len(line)
    while i < n:
        c = line[i]
        if c == "\\":
            i += 2
            continue
        if c == "=":
            return line[:i], line[i + 1:]
        i += 1
    return None, None

def parse_tr(path):
    """返回 (textdomain, key->value dict, 异常行列表)"""
    tdomain, kv, bad = None, {}, []
    with open(path, encoding="utf-8-sig") as f:  # 同时容忍 BOM
        lines = f.read().split("\n")
    for i, line in enumerate(lines, 1):
        if line == "":
            continue
        if tdomain is None:
            m = re.match(r"^# textdomain: (.*)$", line)
            if m:
                tdomain = m.group(1).strip()
                continue
        if line.startswith("#"):
            continue
        key, value = split_key_value(line)
        if key is None:
            bad.append((i, "无未转义 '=': " + line[:50]))
            continue
        kv[unescape_translate(key)] = value
    return tdomain, kv, bad

def main():
    with open(os.path.join(HERE, "batch1_strings.json"), encoding="utf-8") as f:
        strings = json.load(f)

    mod_paths = {}
    for root, dirs, files in os.walk(MODS_DIR):
        if "mod.conf" in files:
            with open(os.path.join(root, "mod.conf"), encoding="utf-8") as f:
                for line in f:
                    m = re.match(r"\s*name\s*=\s*(\S+)", line)
                    if m:
                        mod_paths[m.group(1)] = root
                        break

    total_ok, total_missing, total_extra, total_bad, total_files = 0, 0, 0, 0, 0
    problems = []
    for mod, arr in sorted(strings.items()):
        expect = set(unescape_translate(s) for s in arr)
        mp = mod_paths.get(mod)
        tr_path = os.path.join(mp, "locale", "zh_CN.tr") if mp else None
        if not tr_path or not os.path.exists(tr_path):
            if arr:
                problems.append("%s: zh_CN.tr 不存在" % mod)
                total_missing += len(arr)
            continue
        total_files += 1
        td, kv, bad = parse_tr(tr_path)
        if td != mod:
            problems.append("%s: textdomain 头错误: %r" % (mod, td))
        for ln, msg in bad:
            problems.append("%s.tr:%d %s" % (mod, ln, msg))
            total_bad += 1
        got = set(kv.keys())
        missing = expect - got
        extra = got - expect
        if missing:
            problems.append("%s: 缺 %d 个 key, 例: %r" % (mod, len(missing), sorted(missing)[0][:60]))
            total_missing += len(missing)
        if extra:
            problems.append("%s: 多 %d 个 key, 例: %r" % (mod, len(extra), sorted(extra)[0][:60]))
            total_extra += len(extra)
        if not missing and not extra and not bad and td == mod:
            total_ok += len(arr)

    print("校验文件: %d, 完整命中 key: %d" % (total_files, total_ok))
    print("缺失 key: %d, 多余 key: %d, 格式异常行: %d" % (total_missing, total_extra, total_bad))
    if problems:
        print("-" * 60)
        for p in problems:
            print("!! " + p)
        sys.exit(1)
    print("全部通过: 每个 .tr 的 key 与运行时 S() 字符串一一对应")

if __name__ == "__main__":
    main()
