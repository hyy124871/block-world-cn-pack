-- test_cheats: server-side smoke test for mcl_zh_cheats.
-- Uses core.execute_chatcommand to drive /cheats, /gamerule and the wrapped
-- /gamemode, asserting results against engine state. No client required.

local result_file = core.get_worldpath() .. "/cheats-test-results.txt"

local function report(message)
	local file = io.open(result_file, "a")
	if file then
		file:write(os.date("%Y-%m-%d %H:%M:%S"), " ", message, "\n")
		file:close()
	end
	core.log("action", "[test_cheats] " .. message)
end

local function run_cmd(cmd)
	-- Luanti 5.17 has no public execute_chatcommand; invoke the handler directly
	-- (same entry point the chat dispatcher uses, minus the privs layer).
	local cmdname, param = cmd:match("^/(%S+)%s*(.*)$")
	local def = cmdname and core.registered_chatcommands[cmdname]
	if not def then
		return "NO_SUCH_COMMAND " .. tostring(cmdname)
	end
	local ok, ret = def.func("singleplayer", param or "")
	return (ok and "OK " or "ERR ") .. tostring(ret or "")
end

local function contains(text, needle)
	return text:find(needle, 1, true) ~= nil
end

local function finish()
	core.log("action", "[test_cheats] ALL DONE")
end

core.after(2, function()
	-- 1. commands registered
	local ok_cheats = core.registered_chatcommands["cheats"] ~= nil
	local ok_gamerule = core.registered_chatcommands["gamerule"] ~= nil
	report((ok_cheats and "CHEATS_REG_PASS" or "CHEATS_REG_FAIL"))
	report((ok_gamerule and "GAMERULE_REG_PASS" or "GAMERULE_REG_FAIL"))
	-- craftguide settings as seen by the engine
	report("CRAFTGUIDE progressive=" .. tostring(core.settings:get_bool("mcl_craftguide_progressive_mode", true))
		.. " strict=" .. tostring(core.settings:get_bool("mcl_craftguide_strict_mode", true)))
end)

core.after(3, function()
	-- 2. gate closed: gamerule must refuse before cheats enabled
	local ret = run_cmd("/gamerule keepInventory")
	local gated = contains(ret, "作弊") and contains(ret, "cheats on")
	report((gated and "GAMERULE_GATE_PASS" or "GAMERULE_GATE_FAIL") .. " ret=" .. ret)
end)

core.after(4, function()
	-- 3. cheats status defaults to off
	local ret = run_cmd("/cheats status")
	report((contains(ret, "关闭") and "CHEATS_STATUS_PASS" or "CHEATS_STATUS_FAIL") .. " ret=" .. ret)
end)

core.after(5, function()
	-- 4. enable cheats
	local ret = run_cmd("/cheats on")
	report((contains(ret, "已开启") and "CHEATS_ON_PASS" or "CHEATS_ON_FAIL") .. " ret=" .. ret)
end)

core.after(6, function()
	-- 5. keepInventory true takes effect at runtime
	local ret = run_cmd("/gamerule keepInventory true")
	local eff = core.settings:get_bool("mcl_keepInventory", false)
	report(((eff and contains(ret, "true")) and "KEEPINV_PASS" or "KEEPINV_FAIL") .. " eff=" .. tostring(eff) .. " ret=" .. ret)
end)

core.after(7, function()
	-- 6. wrapped /gamemode: gate open -> falls through to original handler
	-- (no player online -> original returns its own failure, NOT the gate message)
	local ret = run_cmd("/gamemode creative")
	local passed = not contains(ret, "需要先开启作弊")
	report((passed and "GAMEMODE_GATE_PASS" or "GAMEMODE_GATE_FAIL") .. " ret=" .. ret)
end)

core.after(8, function()
	-- 7. keepInventory back off
	run_cmd("/gamerule keepInventory false")
	local eff = core.settings:get_bool("mcl_keepInventory", false)
	report((not eff and "KEEPINV_OFF_PASS" or "KEEPINV_OFF_FAIL") .. " eff=" .. tostring(eff))
end)

core.after(9, function()
	-- 8. cheats off closes the gate again
	run_cmd("/cheats off")
	local ret = run_cmd("/gamerule keepInventory true")
	local gated = contains(ret, "作弊")
	report((gated and "CHEATS_OFF_GATE_PASS" or "CHEATS_OFF_GATE_FAIL") .. " ret=" .. ret)
	finish()
end)
