-- 中文翻译包验证：server 侧只验证管线（get_translator 可用、escape 转发、占位符替换、不崩溃）
-- 译文命中由 verify_tr.py 离线格式校验 + 用户客户端实测双证据确认
local function report(line)
	local f = io.open(core.get_worldpath() .. "/trans-test-results.txt", "a")
	if f then
		f:write(line .. "\n")
		f:close()
	end
end

core.register_on_mods_loaded(function()
	core.after(4, function()
		local pass, fail = 0, 0
		local mods = { "mcl_core", "mcl_tools", "mcl_chests", "mcl_craftguide", "mcl_armor",
			"mcl_anvils", "mcl_beds", "mcl_books", "mcl_farming", "mcl_nether" }
		for _, mod in ipairs(mods) do
			local ok, tr = pcall(core.get_translator, mod, "zh_CN")
			if ok and type(tr) == "function" then
				pass = pass + 1
			else
				fail = fail + 1
				report("FAIL get_translator " .. mod .. ": " .. tostring(tr))
			end
		end
		report("INFO get_translator 可用 mod 数: " .. pass .. "/" .. #mods)
		-- 占位符替换（escape 模式下参数被 \x1b(F..\x1b(E) 包裹, 先剥离再断言）
		local tr = core.get_translator("mcl_beds", "zh_CN")
		local r = core.strip_colors(tr("@1/@2 players currently in bed.", "3", "5"))
		local ok = r:find("3", 1, true) ~= nil and r:find("5", 1, true) ~= nil
		report((ok and "PASS " or "FAIL ") .. "占位符替换 => " .. r:gsub("\n", "\\n"))
		if ok then pass = pass + 1 else fail = fail + 1 end
		-- 含占位符的词条必须传参（回归上次崩溃点）
		local tr2 = core.get_translator("mcl_books", "zh_CN")
		local r2 = core.strip_colors(tr2("Text is @1 characters too long for one book.\nIt will be capped at @2 characters.", "3", "2"))
		local ok2 = r2:find("3", 1, true) ~= nil and r2:find("2", 1, true) ~= nil
		report((ok2 and "PASS " or "FAIL ") .. "换行+占位符词条 => " .. r2:gsub("\n", "\\n"))
		if ok2 then pass = pass + 1 else fail = fail + 1 end
		report(("RESULT pass=%d fail=%d"):format(pass, fail))
		report("END")
	end)
end)
