@echo off
setlocal
chcp 65001 >nul
set "ROOT=%~dp0"
set "GAMEHOME=%ROOT%engine\luanti-5.17.0-win64"
set "ENGINE=%GAMEHOME%\bin\luanti.exe"
if not exist "%ENGINE%" (
  echo 未找到 Luanti 引擎。请确认 engine 文件夹已完整解压。
  pause
  exit /b 1
)
if not exist "%GAMEHOME%\games\mineclonia\game.conf" (
  echo 未找到 Mineclonia，请确认 games\mineclonia 文件夹存在。
  pause
  exit /b 1
)
if not exist "%ROOT%config\minetest.conf" (
  echo 未找到游戏配置文件：config\minetest.conf
  pause
  exit /b 1
)
pushd "%GAMEHOME%"
"%ENGINE%" --config "%ROOT%config\minetest.conf" --gameid mineclonia
set "EXITCODE=%ERRORLEVEL%"
popd
if not "%EXITCODE%"=="0" (
  echo 游戏退出代码：%EXITCODE%
  pause
)
exit /b %EXITCODE%
