@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
set "ROOT=%~dp0"
set "WORLDS=%ROOT%engine\luanti-5.17.0-win64\worlds"
set "BAK=%ROOT%backups"

if not exist "%WORLDS%\worlds.txt" if not exist "%WORLDS%\*" (
  echo [X] 未找到存档目录：%WORLDS%
  pause
  exit /b 1
)
if not exist "%BAK%" mkdir "%BAK%"

set "STAMP=%date:~0,4%%date:~5,2%%date:~8,2%-%time:~0,2%%time:~3,2%%time:~6,2%"
set "STAMP=%STAMP: =0%"
set "DEST=%BAK%\worlds-%STAMP%"

robocopy "%WORLDS%" "%DEST%" /E /NFL /NDL /NJH /NJS >nul
if errorlevel 8 (
  echo [X] 备份失败 robocopy code=%errorlevel%
  pause
  exit /b 1
)
echo [OK] 已备份到 backups\worlds-%STAMP%

rem 滚动：仅保留最近 3 份
set /a n=0
for /f "delims=" %%d in ('dir /b /a:d /o-n "%BAK%\worlds-*" 2^>nul') do (
  set /a n+=1
  if !n! GTR 3 (
    rd /s /q "%BAK%\%%d"
    echo [OK] 清理旧备份 %%d
  )
)
echo [OK] 完成，保留最近 3 份
pause
